%% Ques Max z = 6*x1 + 5*x2
% st -> x1 + x2 <= 5
% -> 3*x1 + 2*x2 <= 12
% -> x1 * x2 >= 0
% Writing this in standard form -> Introducing slack variables for inequalities
% Maximize z = 6*x1 + 5*x2
% Subject to: (Taking Slack as X for easier syntax of the code)
% x1 + x2 + x3 = 5
% 3*x1 + 2*x2 + x4 = 12
% x1, x2, s3, x4 >= 0

%% Phase 1, Input parameters

clc; 
clear all;
clear figure;


C = [6 5 0 0];
z = @(X) C*X;


A = [1 1 1 0;
    3 2 0 1]; % Coefficients for the constraints
b = [5; 12]; % Right-hand side values for the constraints



m = size(A, 1); % Number of contraints
n = size(A, 2); % Number of variables 

%% Phase 2, Finding Basic Solution set and basic feasable set 
basicsol = [];
bfsol = [];
ncm = nchoosek(n, m); % This will give you combination value
pair = nchoosek(1:n, m); % This will give pairs, like pairs of 2 variables for this case 

for i = 1:ncm
    basicvar_index = pair(i, :);
    y = zeros(n, 1);
    % Solve for the basic feasible solution
    X = A(:, basicvar_index) \ b; 
    y(basicvar_index) = X;
    basicsol = [basicsol y];
    if(X >= 0)
        bfsol = [bfsol y];
    end
end

disp(basicsol)
disp(bfsol)

%% Phase 3 Optimal Solution and Optimal Value 
cost = z(bfsol);
[opt_val index] = max(cost);
optsol = bfsol(: , index);
disp('Optimal Solution:');
disp(optsol);
